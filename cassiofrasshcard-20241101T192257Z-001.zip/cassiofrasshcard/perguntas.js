criaCartao(
    'Campanha',
    'Quem foi Raul Menendez?',
    ' é o antagonista, líder rebelde nicaraguense em busca de vingança '
)

criaCartao(
    'Campanha',
    'Pra quem trabalhamos no Black Ops 2?',
    'David Mason e sua equipe estão envolvidos em operações da CIA e  missões com unidades de elite como os Navy SEALs.'
)

criaCartao(
    'Campanha',
    'O que acontece no deserto?',
    'David Manson e sua equipe são enviados para resgatar Frank Woods, que foi capturado por forças inimigas, além do conflito com os mercenários. Você enfrenta os mercenários que trabalham para Raul Menendez. '
)

criaCartao(
    'Zombies',
    'Quais são os 3 robos de Origens?',
    'Thor, Odin e Freya'
)
criaCartao(
    'Zombies',
    'Em Mob of the dead, o que acontece no Ester egg?',
    'Para o ester egg, você coleta todas as peças de um aviao, monta ele, e no final foje porém, acaba batendo em uma ponte na fuga.'
)
criaCartao(
    'Zombies',
    'Em Transit qual é o boss final?',
    'Avogadro. Ele aparece como um inimigo sobrenatural e é uma entidade elétrica que pode causar danos significativos aos jogadores'
)